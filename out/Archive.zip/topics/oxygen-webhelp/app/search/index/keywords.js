define(function() {var keywords=[{w:"FICO",p:["p0"]},{w:"Bechtel",p:["p1"]},{w:"Marine",p:["p1"]},{w:"Propulsion",p:["p1"]},{w:"Corporation",p:["p1"]},{w:"(BMPC)",p:["p1"]},{w:"Contact",p:["p2"]},{w:"Diagram",p:["p3","p4","p20"]},{w:"Samples",p:["p3","p5"]},{w:"Document",p:["p4"]},{w:"Workflow",p:["p4","p21"]},{w:"Editing",p:["p5"]},{w:"Education",p:["p6"]},{w:"Experience",p:["p7"]},{w:"Florida",p:["p8"]},{w:"International",p:["p8"]},{w:"University",p:["p8","p24","p25"]},{w:"(FIU)",p:["p8"]},{w:"How-to...",p:["p9"]},{w:"build",p:["p10"]},{w:"and",p:["p10","p19"]},{w:"deploy",p:["p10"]},{w:"this",p:["p10","p11","p19","p27"]},{w:"website",p:["p10","p27"]},{w:"use",p:["p11"]},{w:"template",p:["p11"]},{w:"Localization",p:["p12"]},{w:"Localizaci\u00F3n",p:["p13"]},{w:"Localisation",p:["p14"]},{w:"\u30ED\u30FC\u30AB\u30EA\u30BC\u30FC\u30B7\u30E7\u30F3",p:["p15"]},{w:"Marathon",p:["p16"]},{w:"TS",p:["p16"]},{w:"Portfolio",p:["p17","p19"]},{w:"Resume",p:["p18","p19"]},{w:"About",p:["p19"]},{w:"Relational",p:["p20"]},{w:"Software",p:["p21"]},{w:"Upgrade",p:["p21"]},{w:"by",p:["p21"]},{w:"Environment",p:["p21"]},{w:"Style",p:["p22"]},{w:"Guide",p:["p22"]},{w:"Sample",p:["p22"]},{w:"Summary",p:["p23"]},{w:"State",p:["p24"]},{w:"of",p:["p24","p27"]},{w:"New",p:["p24"]},{w:"York",p:["p24"]},{w:"College",p:["p24"]},{w:"at",p:["p24"]},{w:"Cortland",p:["p24"]},{w:"Syracuse",p:["p25"]},{w:"Technical",p:["p26"]},{w:"Skills",p:["p26"]},{w:"Troubleshoot",p:["p27"]},{w:"the",p:["p27"]},{w:"building",p:["p27"]},{w:"Video",p:["p28"]},{w:"Instructions",p:["p28"]},{w:"Word",p:["p29"]},{w:"Templates",p:["p29"]}];
var ph={};
ph["p0"]=[0];
ph["p1"]=[1, 2, 3, 4, 5];
ph["p2"]=[6];
ph["p3"]=[7, 8];
ph["p4"]=[9, 10, 7];
ph["p5"]=[11, 8];
ph["p6"]=[12];
ph["p7"]=[13];
ph["p8"]=[14, 15, 16, 17];
ph["p9"]=[18];
ph["p10"]=[19, 20, 21, 22, 23];
ph["p12"]=[26];
ph["p11"]=[24, 22, 25];
ph["p14"]=[28];
ph["p13"]=[27];
ph["p16"]=[30, 31];
ph["p15"]=[29];
ph["p18"]=[33];
ph["p17"]=[32];
ph["p19"]=[34, 22, 33, 20, 32];
ph["p21"]=[36, 37, 38, 39, 10];
ph["p20"]=[35, 7];
ph["p23"]=[43];
ph["p22"]=[40, 41, 42];
ph["p25"]=[51, 16];
ph["p24"]=[44, 16, 45, 46, 47, 48, 49, 50];
ph["p27"]=[54, 55, 56, 45, 22, 23];
ph["p26"]=[52, 53];
ph["p29"]=[59, 60];
ph["p28"]=[57, 58];
     return {
         keywords: keywords,
         ph: ph
     }
});
