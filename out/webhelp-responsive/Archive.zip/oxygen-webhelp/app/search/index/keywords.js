define(function() {var keywords=[{w:"FICO",p:["p0"]},{w:"Bechtel",p:["p1"]},{w:"Marine",p:["p1"]},{w:"Propulsion",p:["p1"]},{w:"Corporation",p:["p1"]},{w:"(BMPC)",p:["p1"]},{w:"Contact",p:["p2"]},{w:"Diagram",p:["p3","p4","p16"]},{w:"Samples",p:["p3","p5"]},{w:"Document",p:["p4"]},{w:"Workflow",p:["p4","p17"]},{w:"Editing",p:["p5"]},{w:"Education",p:["p6"]},{w:"Experience",p:["p7"]},{w:"Florida",p:["p8"]},{w:"International",p:["p8"]},{w:"University",p:["p8","p20","p21"]},{w:"(FIU)",p:["p8"]},{w:"How-to...",p:["p9"]},{w:"build",p:["p10"]},{w:"and",p:["p10","p15"]},{w:"deploy",p:["p10"]},{w:"this",p:["p10","p11","p15"]},{w:"website",p:["p10"]},{w:"use",p:["p11"]},{w:"template",p:["p11"]},{w:"Marathon",p:["p12"]},{w:"TS",p:["p12"]},{w:"Portfolio",p:["p13","p15"]},{w:"Resume",p:["p14","p15"]},{w:"About",p:["p15"]},{w:"Relational",p:["p16"]},{w:"Software",p:["p17"]},{w:"Upgrade",p:["p17"]},{w:"by",p:["p17"]},{w:"Environment",p:["p17"]},{w:"Style",p:["p18"]},{w:"Guide",p:["p18"]},{w:"Sample",p:["p18"]},{w:"Summary",p:["p19"]},{w:"State",p:["p20"]},{w:"of",p:["p20"]},{w:"New",p:["p20"]},{w:"York",p:["p20"]},{w:"College",p:["p20"]},{w:"at",p:["p20"]},{w:"Cortland",p:["p20"]},{w:"Syracuse",p:["p21"]},{w:"Technical",p:["p22"]},{w:"Skills",p:["p22"]},{w:"Video",p:["p23"]},{w:"Instructions",p:["p23"]},{w:"Word",p:["p24"]},{w:"Templates",p:["p24"]}];
var ph={};
ph["p0"]=[0];
ph["p1"]=[1, 2, 3, 4, 5];
ph["p2"]=[6];
ph["p3"]=[7, 8];
ph["p4"]=[9, 10, 7];
ph["p5"]=[11, 8];
ph["p6"]=[12];
ph["p7"]=[13];
ph["p8"]=[14, 15, 16, 17];
ph["p9"]=[18];
ph["p10"]=[19, 20, 21, 22, 23];
ph["p12"]=[26, 27];
ph["p11"]=[24, 22, 25];
ph["p14"]=[29];
ph["p13"]=[28];
ph["p16"]=[31, 7];
ph["p15"]=[30, 22, 29, 20, 28];
ph["p18"]=[36, 37, 38];
ph["p17"]=[32, 33, 34, 35, 10];
ph["p19"]=[39];
ph["p21"]=[47, 16];
ph["p20"]=[40, 16, 41, 42, 43, 44, 45, 46];
ph["p23"]=[50, 51];
ph["p22"]=[48, 49];
ph["p24"]=[52, 53];
     return {
         keywords: keywords,
         ph: ph
     }
});
