define(function() {var keywords=[{w:"FICO",p:["p0"]},{w:"Bechtel",p:["p1"]},{w:"Marine",p:["p1"]},{w:"Propulsion",p:["p1"]},{w:"Corporation",p:["p1"]},{w:"(BMPC)",p:["p1"]},{w:"Contact",p:["p2"]},{w:"Diagram",p:["p3","p4","p17"]},{w:"Samples",p:["p3","p6"]},{w:"Document",p:["p4"]},{w:"Workflow",p:["p4","p18"]},{w:"Editing",p:["p5","p6"]},{w:"Sample",p:["p5","p19"]},{w:"Education",p:["p7"]},{w:"Experience",p:["p8"]},{w:"Florida",p:["p9"]},{w:"International",p:["p9"]},{w:"University",p:["p9","p21","p22"]},{w:"(FIU)",p:["p9"]},{w:"How-to...",p:["p10"]},{w:"build",p:["p11"]},{w:"and",p:["p11","p16"]},{w:"deploy",p:["p11"]},{w:"this",p:["p11","p12","p16"]},{w:"website",p:["p11"]},{w:"use",p:["p12"]},{w:"template",p:["p12"]},{w:"Marathon",p:["p13"]},{w:"TS",p:["p13"]},{w:"Portfolio",p:["p14","p16"]},{w:"Resume",p:["p15","p16"]},{w:"About",p:["p16"]},{w:"Relational",p:["p17"]},{w:"Software",p:["p18"]},{w:"Upgrade",p:["p18"]},{w:"by",p:["p18"]},{w:"Environment",p:["p18"]},{w:"Style",p:["p19"]},{w:"Guide",p:["p19"]},{w:"Summary",p:["p20"]},{w:"State",p:["p21"]},{w:"of",p:["p21"]},{w:"New",p:["p21"]},{w:"York",p:["p21"]},{w:"College",p:["p21"]},{w:"at",p:["p21"]},{w:"Cortland",p:["p21"]},{w:"Syracuse",p:["p22"]},{w:"Technical",p:["p23"]},{w:"Skills",p:["p23"]},{w:"Video",p:["p24"]},{w:"Instructions",p:["p24"]},{w:"Word",p:["p25"]},{w:"Templates",p:["p25"]}];
var ph={};
ph["p0"]=[0];
ph["p1"]=[1, 2, 3, 4, 5];
ph["p2"]=[6];
ph["p3"]=[7, 8];
ph["p4"]=[9, 10, 7];
ph["p5"]=[11, 12];
ph["p6"]=[11, 8];
ph["p7"]=[13];
ph["p8"]=[14];
ph["p9"]=[15, 16, 17, 18];
ph["p10"]=[19];
ph["p12"]=[25, 23, 26];
ph["p11"]=[20, 21, 22, 23, 24];
ph["p14"]=[29];
ph["p13"]=[27, 28];
ph["p16"]=[31, 23, 30, 21, 29];
ph["p15"]=[30];
ph["p18"]=[33, 34, 35, 36, 10];
ph["p17"]=[32, 7];
ph["p19"]=[37, 38, 12];
ph["p21"]=[40, 17, 41, 42, 43, 44, 45, 46];
ph["p20"]=[39];
ph["p23"]=[48, 49];
ph["p22"]=[47, 17];
ph["p25"]=[52, 53];
ph["p24"]=[50, 51];
     return {
         keywords: keywords,
         ph: ph
     }
});
