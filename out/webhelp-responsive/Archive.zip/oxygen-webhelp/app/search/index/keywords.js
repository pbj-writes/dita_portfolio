define(function() {var keywords=[{w:"FICO",p:["p0"]},{w:"Bechtel",p:["p1"]},{w:"Marine",p:["p1"]},{w:"Propulsion",p:["p1"]},{w:"Corporation",p:["p1"]},{w:"(BMPC)",p:["p1"]},{w:"Contact",p:["p2"]},{w:"Education",p:["p3"]},{w:"Experience",p:["p4"]},{w:"Florida",p:["p5"]},{w:"International",p:["p5"]},{w:"University",p:["p5","p14","p15"]},{w:"(FIU)",p:["p5"]},{w:"How-to...",p:["p6"]},{w:"build",p:["p7"]},{w:"and",p:["p7","p12"]},{w:"deploy",p:["p7"]},{w:"this",p:["p7","p8","p12"]},{w:"website",p:["p7"]},{w:"use",p:["p8"]},{w:"template",p:["p8"]},{w:"Marathon",p:["p9"]},{w:"TS",p:["p9"]},{w:"Portfolio",p:["p10","p12"]},{w:"Resume",p:["p11","p12"]},{w:"About",p:["p12"]},{w:"Summary",p:["p13"]},{w:"State",p:["p14"]},{w:"of",p:["p14"]},{w:"New",p:["p14"]},{w:"York",p:["p14"]},{w:"College",p:["p14"]},{w:"at",p:["p14"]},{w:"Cortland",p:["p14"]},{w:"Syracuse",p:["p15"]},{w:"Technical",p:["p16"]},{w:"Skills",p:["p16"]},{w:"Video",p:["p17"]},{w:"Instructions",p:["p17"]},{w:"Word",p:["p18"]},{w:"Templates",p:["p18"]}];
var ph={};
ph["p0"]=[0];
ph["p1"]=[1, 2, 3, 4, 5];
ph["p2"]=[6];
ph["p3"]=[7];
ph["p4"]=[8];
ph["p5"]=[9, 10, 11, 12];
ph["p6"]=[13];
ph["p7"]=[14, 15, 16, 17, 18];
ph["p8"]=[19, 17, 20];
ph["p9"]=[21, 22];
ph["p10"]=[23];
ph["p12"]=[25, 17, 24, 15, 23];
ph["p11"]=[24];
ph["p14"]=[27, 11, 28, 29, 30, 31, 32, 33];
ph["p13"]=[26];
ph["p16"]=[35, 36];
ph["p15"]=[34, 11];
ph["p18"]=[39, 40];
ph["p17"]=[37, 38];
     return {
         keywords: keywords,
         ph: ph
     }
});
