/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {21:6,23:13,11:9,5:13,15:-1,7:14,1:7,6:14,8:7,2:14,4:3,10:9,0:7,3:13,19:14,22:14,12:7,14:-1,9:13,20:6,17:3,24:13,18:13,16:3,13:-1};
});