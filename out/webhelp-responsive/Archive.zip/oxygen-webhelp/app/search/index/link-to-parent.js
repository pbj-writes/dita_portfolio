/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {15:3,17:10,8:6,12:-1,4:11,1:4,3:11,5:4,2:11,7:6,0:4,13:11,16:11,9:4,11:-1,6:10,14:3,18:10,10:-1};
});