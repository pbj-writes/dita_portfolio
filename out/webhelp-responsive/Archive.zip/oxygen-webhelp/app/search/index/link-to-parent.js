/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {9:3,5:4,10:-1,0:4,4:-1,3:-1,7:-1,6:4,1:4,8:3,2:-1};
});