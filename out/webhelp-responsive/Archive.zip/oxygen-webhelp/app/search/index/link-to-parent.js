/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {22:7,24:14,12:10,5:14,16:-1,8:15,1:8,7:15,9:8,2:15,4:3,11:10,0:8,3:14,20:15,23:15,13:8,15:-1,10:14,21:7,18:3,25:14,19:14,17:3,14:-1};
});